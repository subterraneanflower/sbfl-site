/*
 * Canvas/WebGLの2D性能比較サンプルプログラム。
 * ここでは「Canvas」は「WebGLを使わない描画コンテキスト」の意。
 * HTML5のCanvas要素を表すときは「Canvas要素」や「CanvasElement」と表記する。
 */

import 'dart:html';
import 'dart:web_gl';
import 'dart:typed_data';
import 'dart:math';
import 'dart:async';

// スプライト枚数の上限。
// とりあえず5万ぐらいで。
const int SPRITE_LIMIT = 50000;
const int VERTEX_PER_SPRITE = 4;
const int INDEX_PER_SPRITE = 6;

// ここでは面倒だったのでグローバル変数を使っているが、
// これをやると後々地獄を見るのでやめよう。
// リソース管理用のクラスなどを作るといいかもしれない。
ImageElement textureSource;
String vertexShaderSource;
String fragmentShaderSource;

List<Actor> actors;

void main() {
  actors = new List<Actor>();
  
  // テクスチャやシェーダを読み込み終えてから開始。
  loadImage(new Uri.file("atlas.png"))
    .then((img)=>textureSource=img)
    .then((_)=>loadString(new Uri.file("vertex_shader.glsl")))
    .then((vs)=>vertexShaderSource=vs)
    .then((_)=>loadString(new Uri.file("fragment_shader.glsl")))
    .then((fs)=>fragmentShaderSource=fs)
    .then((_)=>start());
}

Future<ImageElement> loadImage(Uri uri) {
  var completer = new Completer<ImageElement>();
  
  var img = new ImageElement(src: uri.toString());
  img.onLoad.listen((_)=>completer.complete(img));
  
  return completer.future;
}

Future<String> loadString(Uri uri) {
  var completer = new Completer<String>();
  HttpRequest.getString(uri.toString()).then((str)=>completer.complete(str));
  return completer.future;
}

// リソースの読み込みが終わってから開始するメイン処理。
void start() {
  const WIDTH  = 900;
  const HEIGHT = 900;
  const SPRITE_SIZE = 16;
  
  var description = new DivElement()..text = "ENTERキーでWebGL切り替え";
  
  var canvas      = new CanvasElement(width: WIDTH, height: HEIGHT);
  var webGlCanvas = new CanvasElement(width: WIDTH, height: HEIGHT);
  
  var fpsCounter       = new DivElement();
  var objectCounter    = new DivElement();
  var webGlFragDisplay = new DivElement(); 
  
  var canvasRenderer   = new CanvasRenderer(canvas);
  var webGlRenderer    = new WebGlRenderer(webGlCanvas, vertexShaderSource, fragmentShaderSource);
  
  document.body.append(description);
  document.body.append(canvas);
  document.body.append(webGlCanvas);
  document.body.append(fpsCounter);
  document.body.append(objectCounter);
  document.body.append(webGlFragDisplay);
  
  Renderer renderer;
  var useWebGl = true;
  var prevTime = 0.0;
  var frameCount = 0;
  var removes = new List<Actor>();
  
  // レンダラ切り替え関数。
  void switchRenderer(bool webGlEnabled) {
    renderer = webGlEnabled ? webGlRenderer : canvasRenderer;
    canvas.hidden = webGlEnabled;
    webGlCanvas.hidden = !webGlEnabled;
    webGlFragDisplay.text = "WebGL: ${webGlEnabled ? "on" : "off"}";
  }
  
  // ENTERキーでレンダラ切り替え。
  window.onKeyDown.listen((ke){
    if(ke.keyCode == KeyCode.ENTER) {
      useWebGl = !useWebGl;
      switchRenderer(useWebGl);
    }
  });
  
  // 初期レンダラ適用。
  switchRenderer(useWebGl);
  
  // メインループ。
  void loop(num timestamp) {
    renderer.clear(0, 0, 0);
    
    var elapsed = (timestamp - prevTime) / 1000;
    if(elapsed >= 1.0) {
      // フレームレート計測 & 表示。
      var fps = frameCount / elapsed;
      fpsCounter.text = "${fps.toStringAsPrecision(5)} fps";
      frameCount = 0;
      prevTime = timestamp;
      
      // オブジェクト数表示。
      objectCounter.text = "${actors.length} objects";
    }
    
    // 数フレームごとに弾を出す。
    // 画面を埋め尽くす程度に適当に調整。
    if(frameCount%2==0) {
      for(var i=0; i<360; i+=2) {
        actors.add(new KunaiBullet(textureSource, WIDTH/2.0, HEIGHT/2.0, 3.0, (i+timestamp)/180*PI));
      }
    }
    
    // 表示オブジェクトの更新と描画。
    // リスト走査中に削除はできないので
    // いったん他のリストに入れてからまとめて削除。
    actors.forEach((actr){
      actr.update();
      if(actr.x < 0 - SPRITE_SIZE || actr.x > WIDTH ||
         actr.y < 0 - SPRITE_SIZE || actr.y > HEIGHT) {
        removes.add(actr);
      }
    });
    removes.forEach((a)=>actors.remove(a));
    removes.clear();
    actors.forEach((actr)=>actr.draw(renderer));
    
    renderer.flush();
    frameCount++;
    window.requestAnimationFrame(loop); //毎フレーム呼び出す必要がある。
  }
  
  window.requestAnimationFrame(loop);
}

/*
 * 表示オブジェクト。
 */
abstract class Actor {
  void draw(Renderer renderer);
  void update();
}

class KunaiBullet implements Actor {
  ImageElement sprite;
  double x;
  double y;
  double dx;
  double dy;
  double speed;
  double angle;
  
  List<Rectangle<double>> _textureList = [const Rectangle<double>(0.0, 16.0, 16.0, 16.0),  // 赤
                                          const Rectangle<double>(16.0, 16.0, 16.0, 16.0), // 緑
                                          const Rectangle<double>(32.0, 16.0, 16.0, 16.0), // 水
                                          const Rectangle<double>(48.0, 16.0, 16.0, 16.0)];// 紫
  Rectangle<double> _texture;
  
  KunaiBullet(this.sprite, this.x, this.y, this.speed, [this.angle=0.0]) {
    dx = speed * cos(angle-90/180*PI);
    dy = speed * sin(angle-90/180*PI);
    
    // カラフルに。
    // 動的に色を変える方法も考えたものの
    // 色の数だけテクスチャを用意する方針に。
    var rnd = new Random();
    _texture = _textureList[rnd.nextInt(_textureList.length)];
  }
  
  void update() {
    x += dx;
    y += dy;
  }
  
  void draw(Renderer renderer) {
    var dest = new Point<double>(x,y);
    renderer.drawSprite(sprite, dest, _texture, angle);
  }
}

/*
 * Canvas/WebGL共通のレンダラインターフェイス
 */
abstract class Renderer {
  void clear(int r, int g, int b, [double a]);
  void drawSprite(ImageElement source, Point<double> destination, Rectangle<double> textureRect, double angle);
  void flush();
}

/*
 * Canvasでのレンダリング。
 * 
 * シンプルで使いやすい。
 * 環境にもよるが、こちらでも十分な速度は出るので
 * WebGLを使うに一度試してみたほうがいい。
 */
class CanvasRenderer implements Renderer {
  CanvasElement _canvas;
  CanvasRenderingContext2D _context;
  int _width;
  int _height;
  
  CanvasRenderer(this._canvas) {
    _context = _canvas.context2D;
    _width  = _canvas.width;
    _height = _canvas.height;
  }
  
  void clear(int r, int g, int b, [double a=1.0]) {
    _context.setFillColorRgb(r, g, b, a);
    _context.fillRect(0, 0, _width, _height);
  }
  
  void drawSprite(ImageElement source, Point<double> destination, Rectangle<double> textureRect, double angle) {
    // 回転は原点を中心に行われるので、
    // 原点に移動→回転→元の位置に戻す
    // という手順を踏む必要がある。
    // 内部的には行列演算になっているようで、逆順に適用していく必要あり。
    var centerX = (destination.x + textureRect.width~/2); // 「~/」は結果が整数になる割り算
    var centerY = (destination.y + textureRect.width~/2);
    _context.translate(centerX, centerY);
    _context.rotate(angle);
    _context.translate(-centerX, -centerY);
    _context.drawImageScaledFromSource(source, textureRect.left, textureRect.top, textureRect.width, textureRect.height, // source
                                       destination.x, destination.y, textureRect.width, textureRect.height);             // dest
    _context.setTransform(1, 0, 0, 1, 0, 0); // リセット。rotate(-angle)でもいいはず。
  }
  
  void flush()=>null; // canvasでは不要なので何もしない。
}

/*
 * WebGLでのレンダリング。
 * 
 * 3Dグラフィックス向けのAPIなので煩雑。
 * うまく使えば素のCanvasより速度が出る。
 * C言語由来のAPIのため、オブジェクト指向のオの字も感じられない作りになっているので
 * 実際に使うときはある程度ラップした方がいいだろう。
 * 
 * OpenGLES2.0がベースになっているので、知りたい情報があるときはOpenGLES2.0についても
 * 調べてみるといいだろう。WebGL2.0ではOpenGLES3.0の機能が取り込まれる予定。
 * 
 * コンテキストを喪失することがあるので、必要に応じて
 * CanvasElementのonWebGlContextLostイベントやonWebGlContextRestoredイベントで
 * うまくハンドリングする。
 */ 
class WebGlRenderer implements Renderer {
  CanvasElement _canvas;
  RenderingContext _context;
  int _width;
  int _height;
  
  Buffer _vertexBuffer;
  Buffer _vertexIndexBuffer;

  Float32List _vertices;
  Uint16List  _vertexIndices;
  
  int _spriteCount;
  
  WebGlRenderer(this._canvas, String vertexShaderSource, String fragmentShaderSource) {
    _context = _canvas.getContext3d();
    _width  = _canvas.width;
    _height = _canvas.height;
 
    _spriteCount = 0;
    
    _context.viewport(0, 0, _width, _height);
    
    // シェーダーのコンパイル。
    // 本来はコンパイルステータスを確認すべきだが
    // ここでは省略。
    var vertexShader = _context.createShader(RenderingContext.VERTEX_SHADER);
    _context.shaderSource(vertexShader, vertexShaderSource);
    _context.compileShader(vertexShader);
    
    var fragmentShader = _context.createShader(RenderingContext.FRAGMENT_SHADER);
    _context.shaderSource(fragmentShader, fragmentShaderSource);
    _context.compileShader(fragmentShader);
    
    // プログラムの作成。
    // リンクのステータスを確認すべきだが同上。
    var program = _context.createProgram();
    _context.attachShader(program, vertexShader);
    _context.attachShader(program, fragmentShader);
    _context.linkProgram(program);
    _context.useProgram(program);
    
    // バッファの作成。
    // 頂点バッファとインデックスバッファの2つ。
    // ここでは頂点バッファは以下の構成にしている。
    // [座標(vec2)][回転情報(vec4)][回転軸(vec2)][テクスチャ座標(vec2)]
    //
    // 情報ごとに違うバッファを作成するより、ひとつのバッファにまとめるほうが
    // メモリアクセス等の関係で性能面において有利だと言われている。
    _vertexBuffer      = _context.createBuffer();
    _vertexIndexBuffer = _context.createBuffer();
    
    // 頂点バッファ。頂点ごとの情報を保存する。
    // 今回は2次元座標しか扱わないので座標のsizeは2。
    // strideは頂点情報のサイズなのでvec2+vec4+vec2+vec2で10。
    // offsetはstride内での位置なので各々計算する。
    // strideもoffsetもバイト数で指定する。
    const STRIDE               = Float32List.BYTES_PER_ELEMENT * 10;
    const ROTATION_OFFSET      = Float32List.BYTES_PER_ELEMENT * 2;
    const ROTATION_AXIS_OFFSET = Float32List.BYTES_PER_ELEMENT * 6;
    const TEXTURE_OFFSET       = Float32List.BYTES_PER_ELEMENT * 8;
    
    const BUFFER_LENGTH = SPRITE_LIMIT * VERTEX_PER_SPRITE * STRIDE;
    const BUFFER_SIZE   = Float32List.BYTES_PER_ELEMENT * BUFFER_LENGTH;
    
    const POSITION_SIZE      = 2;
    const ROTATION_SIZE      = 4;
    const ROTATION_AXIS_SIZE = 2;
    const TEXTURE_SIZE       = 2;
        
    // 操作対象のバッファをbindしてから作業をする。
    _context.bindBuffer(RenderingContext.ARRAY_BUFFER, _vertexBuffer);
    // あらかじめ頂点用のメモリを確保しておく。
    // 確保せずに描画ごとにbufferDataTypedで直接転送してもいいが
    // おそらく転送ごとにメモリ確保が生じるので、多数の頂点を扱う今回は避ける。
    // usgaeパラメータにはDYNAMIC_DRAWのほかにSTATIC_DRAWなどもあるが、
    // どれを指定しても大きな差は出なかった。要検証。
    _context.bufferData(RenderingContext.ARRAY_BUFFER, BUFFER_SIZE, RenderingContext.DYNAMIC_DRAW);
    // 各頂点情報の設定。
    var vtxAttrLocation      = _context.getAttribLocation(program, "vertexPosition");
    var rotationLocation     = _context.getAttribLocation(program, "rotation");
    var rotationAxisLocation = _context.getAttribLocation(program, "rotationAxis");
    var textureCoordLocation = _context.getAttribLocation(program, "textureCoord");
    _context.enableVertexAttribArray(vtxAttrLocation);
    _context.enableVertexAttribArray(rotationAxisLocation);
    _context.enableVertexAttribArray(rotationLocation);
    _context.enableVertexAttribArray(textureCoordLocation);
    _context.vertexAttribPointer(vtxAttrLocation, POSITION_SIZE, RenderingContext.FLOAT, false, STRIDE, 0);
    _context.vertexAttribPointer(rotationLocation, ROTATION_SIZE, RenderingContext.FLOAT, false, STRIDE, ROTATION_OFFSET);
    _context.vertexAttribPointer(rotationAxisLocation, ROTATION_AXIS_SIZE, RenderingContext.FLOAT, false, STRIDE, ROTATION_AXIS_OFFSET);
    _context.vertexAttribPointer(textureCoordLocation, TEXTURE_SIZE, RenderingContext.FLOAT, false, STRIDE, TEXTURE_OFFSET);
    
    // インデックスバッファも同様に。
    const INDEX_LENGTH  = SPRITE_LIMIT * INDEX_PER_SPRITE;
    const INDEX_SIZE    = Float32List.BYTES_PER_ELEMENT * INDEX_LENGTH;
    
    _context.bindBuffer(RenderingContext.ELEMENT_ARRAY_BUFFER, _vertexIndexBuffer);
    _context.bufferData(RenderingContext.ELEMENT_ARRAY_BUFFER, INDEX_SIZE, RenderingContext.DYNAMIC_DRAW);
    
    // 頂点情報の格納に使うリスト。
    // 普通のListで保持しておいて後で変換しても良いが
    // JavaScriptに変換した際のリスト操作コストが高かったので
    // 今回は直接弄る方針にした。
    _vertices      = new Float32List(BUFFER_LENGTH);
    _vertexIndices = new Uint16List(INDEX_LENGTH);
    
    // シェーダのuniform変数の設定。
    // 詳しくは各glslファイルの変数を参照。
    
    // デフォルトの状態だとxy座標ともに[-1.0, 1.0]が表示されるので、
    // 2Dグラフィックスで一般的な[0.0, width or height]座標に変換する。
    var xScale = 2.0/_width.toDouble();
    var yScale = -2.0/_height.toDouble(); // 上下逆
    
    var scalingMatrix = new Float32List.fromList([
      xScale, 0.0   , 0.0, 0.0,
      0.0   , yScale, 0.0, 0.0,
      0.0   , 0.0   , 1.0, 0.0,
      0.0   , 0.0   , 0.0, 1.0 
    ]);
    
    // (0, 0)が中心になってしまうので左上に持ってきてやる。
    var translationMatrix = new Float32List.fromList([
      1.0, 0.0 , 0.0, 0.0,
      0.0, 1.0 , 0.0, 0.0,
      0.0, 0.0 , 1.0, 0.0,
      -1.0, 1.0 , 0.0, 1.0 
    ]);
    
    var scalingLocation = _context.getUniformLocation(program, "scaling");
    var translationLocation = _context.getUniformLocation(program, "translation");
    _context.uniformMatrix4fv(translationLocation, false, translationMatrix);
    _context.uniformMatrix4fv(scalingLocation, false, scalingMatrix);
    
    // テクスチャを転送。
    // だいぶ負担がかかるので、できればまとめて送っておいた方がいい。
    // ここでは1枚しか使用していないが、テクスチャユニットを切り替えて複数利用可能。
    // テクスチャサイズは縦横ともに2のべき乗ピクセルである必要がある。
    // 例えば32x32や16x64など。
    // 環境ごとに枚数やサイズの制限があるので注意。
    var textureLocation = _context.getUniformLocation(program, "texture");
    var texture = _context.createTexture();
    
    _context.activeTexture(RenderingContext.TEXTURE0);
    _context.bindTexture(RenderingContext.TEXTURE_2D, texture);
    _context.texImage2D(RenderingContext.TEXTURE_2D,
                        0, 
                        RenderingContext.RGBA,
                        RenderingContext.RGBA,
                        RenderingContext.UNSIGNED_BYTE,
                        textureSource);
    _context.generateMipmap(RenderingContext.TEXTURE_2D);
    
    // 使用したいテクスチャ番号を逐一指定する。
    // アクティブにするときに使用した定数（RenderingContext.TEXTURE0）などではなく、
    // 0などの番号で指定する必要がある。
    _context.uniform1i(textureLocation, 0);
    
    // アルファブレンドを有効にする。
    // このあたりはいろいろと細かい設定があるので
    // 詳しくはGoogle先生に。
    _context.blendFunc(RenderingContext.SRC_ALPHA, RenderingContext.ONE);
    _context.enable(RenderingContext.BLEND);
  }
  
  void clear(int r, int g, int b, [double a=1.0]) {
    // RGB値は[0.0, 1.0]で指定する。
    _context.clearColor(r/255.0, g/255.0, b/255.0, a);
    // 今回はカラーバッファのみクリア。
    // デプスバッファを使うときもここでクリアする。
    _context.clear(RenderingContext.COLOR_BUFFER_BIT);
  }
  
  void drawSprite(ImageElement source, Point<double> destination, Rectangle<double> textureRect, double angle) {
    // 呼び出しごとに描画していると無駄が多いので、
    // 座標だけを保持しておきflush時に一度に描画するようにしている。
    // ドローコールの回数はパフォーマンスに直結する。
    
    // 頂点情報。以下の順番。
    // [座標(vec2)]
    // [回転情報(vec4)]
    // [回転軸(vec2)]
    // [テクスチャ座標(vec2)] 
    // 
    // ※テクスチャ座標は[0.0, 1.0]へ正規化する。
    //   テクスチャサイズにかかわらず左下が(0.0, 0.0)で
    //   右上が(1.0, 1.0)となる。
    var sinAngle = sin(-angle);
    var cosAngle = cos(-angle);
    var centerX  = destination.x + textureRect.width/2;
    var centerY  = destination.y + textureRect.height/2;
    var textureWidth  = source.width;
    var textureHeight = source.height;
    
    // 4頂点分の情報。
    var vtxOffset = _spriteCount * 10 * 4;
    _vertices[vtxOffset+0] = destination.x;
    _vertices[vtxOffset+1] = destination.y;
    _vertices[vtxOffset+2] = cosAngle;
    _vertices[vtxOffset+3] = -sinAngle;
    _vertices[vtxOffset+4] = sinAngle;
    _vertices[vtxOffset+5] = cosAngle;
    _vertices[vtxOffset+6] = centerX;
    _vertices[vtxOffset+7] = centerY;
    _vertices[vtxOffset+8] = textureRect.left/textureWidth;
    _vertices[vtxOffset+9] = textureRect.top/textureHeight;
    
    _vertices[vtxOffset+10] = destination.x + textureRect.width;
    _vertices[vtxOffset+11] = destination.y;
    _vertices[vtxOffset+12] = cosAngle;
    _vertices[vtxOffset+13] = -sinAngle;
    _vertices[vtxOffset+14] = sinAngle;
    _vertices[vtxOffset+15] = cosAngle;
    _vertices[vtxOffset+16] = centerX;
    _vertices[vtxOffset+17] = centerY;
    _vertices[vtxOffset+18] = textureRect.right/textureWidth;
    _vertices[vtxOffset+19] = textureRect.top/textureHeight;
    
    _vertices[vtxOffset+20] = destination.x;
    _vertices[vtxOffset+21] = destination.y + textureRect.height;
    _vertices[vtxOffset+22] = cosAngle;
    _vertices[vtxOffset+23] = -sinAngle;
    _vertices[vtxOffset+24] = sinAngle;
    _vertices[vtxOffset+25] = cosAngle;
    _vertices[vtxOffset+26] = centerX;
    _vertices[vtxOffset+27] = centerY;
    _vertices[vtxOffset+28] = textureRect.left/textureWidth;
    _vertices[vtxOffset+29] = textureRect.bottom/textureHeight;
    
    _vertices[vtxOffset+30] = destination.x + textureRect.width;
    _vertices[vtxOffset+31] = destination.y + textureRect.height;
    _vertices[vtxOffset+32] = cosAngle;
    _vertices[vtxOffset+33] = -sinAngle;
    _vertices[vtxOffset+34] = sinAngle;
    _vertices[vtxOffset+35] = cosAngle;
    _vertices[vtxOffset+36] = centerX;
    _vertices[vtxOffset+37] = centerY;
    _vertices[vtxOffset+38] = textureRect.right/textureWidth;
    _vertices[vtxOffset+39] = textureRect.bottom/textureHeight;
    
    // インデックスバッファで使う頂点番号。
    // 例えば0-1-2と1-2-3を使えば4頂点で四角形が描画できる。
    var startVertex = _spriteCount * 4;
    var idxOffset   = _spriteCount * 6;
    _vertexIndices[idxOffset+0] = startVertex;
    _vertexIndices[idxOffset+1] = startVertex+1;
    _vertexIndices[idxOffset+2] = startVertex+2;
    _vertexIndices[idxOffset+3] = startVertex+1;
    _vertexIndices[idxOffset+4] = startVertex+2;
    _vertexIndices[idxOffset+5] = startVertex+3;

    _spriteCount ++;
  }
  
  void flush() {
    // GPUに頂点データを転送。
    _context.bindBuffer(RenderingContext.ARRAY_BUFFER, _vertexBuffer);
    _context.bufferSubDataTyped(RenderingContext.ARRAY_BUFFER, 0, _vertices);
    
    _context.bindBuffer(RenderingContext.ELEMENT_ARRAY_BUFFER, _vertexIndexBuffer);
    _context.bufferSubDataTyped(RenderingContext.ELEMENT_ARRAY_BUFFER, 0, _vertexIndices);
    
    // いわゆる「ドローコール」というやつ。
    // ここではテクスチャ1枚しか使っていないので一度しか呼び出していないが
    // 複数回呼び出すことの方が多い。
    // 負担が大きいので、できるだけ少なくした方がいい。
    // スプライト1枚ごとに呼び出してもいいが、Canvasより遅くなる。
    _context.drawElements(RenderingContext.TRIANGLES, _spriteCount * INDEX_PER_SPRITE, RenderingContext.UNSIGNED_SHORT, 0);
    
    // 描画時間を計測するため、同期的に実行されるfinish()を使用している。
    // 通常はflush()を使う。
    _context.finish();
    _clearVertices();
  }
  
  void _clearVertices() {
    _spriteCount = 0;
  }
}